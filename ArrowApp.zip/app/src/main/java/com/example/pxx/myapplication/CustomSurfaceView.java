package com.example.pxx.myapplication;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathEffect;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Region;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by  on 2017/4/18.
 */

public class CustomSurfaceView extends SurfaceView implements
        SurfaceHolder.Callback, Runnable, Handler.Callback {
    // SurfaceHolder
    private SurfaceHolder mSurfaceHolder;

    private Context context;

    private int viewWidth;
    private int viewHeight;

    private boolean startDraw;
    //半径
    private int radius;
    // Path
    private Path mPath = new Path();
    // 画笔
    private Paint mpaint = new Paint();

    private Canvas canvas;
    //滑板背景（保存绘制的图片）
    private Bitmap saveBitmap;
    //图像
    Bitmap bitmap;
    private LinkedList<DrawPath> drawPathList = new LinkedList<>();
    private Region re = new Region();
    private boolean isMove;
    private boolean isReMove, isReMove1;
    private int curposition, rcurposition, rcurposition1;
    private int x, y;


    public CustomSurfaceView(Context context) {
        this(context, null);
        saveBitmap = Bitmap.createBitmap(720, 1000, Bitmap.Config.ARGB_8888);
        this.context = context;

    }

    public CustomSurfaceView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);

    }

    public CustomSurfaceView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        initView(); // 初始化

    }

    private void initView() {
        setMeasuredDimension(720, 1000);
        mSurfaceHolder = getHolder();
        mSurfaceHolder.addCallback(this);
        mSurfaceHolder.setFormat(PixelFormat.TRANSPARENT);
        setFocusable(true);
        setFocusableInTouchMode(true);
        this.setKeepScreenOn(true);
        initPaint();
    }

    private Handler handler = new Handler(this);

    @Override
    public void run() {
        long startTime = System.currentTimeMillis();
        while (startDraw) {
            long endTime = System.currentTimeMillis();
            if (endTime - startTime < 100) {
                try {
                    Thread.sleep(100 + startTime - endTime);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.bg);
            ;
            handler.sendEmptyMessage(1);
        }
    }


    /*
         * 创建
         */
    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        startDraw = true;

        canvas = mSurfaceHolder.lockCanvas();
        canvas.setBitmap(saveBitmap);
        mSurfaceHolder.unlockCanvasAndPost(canvas);
        new Thread(this).start();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        viewWidth = getWidth();
        viewHeight = getHeight();

    }

    /*
         *
         */
    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width,
                               int height) {
    }

    /*
     * 销毁
     */
    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        startDraw = false;
    }

    int startX;
    int startY;
    int stopX;
    int stopY;

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                //计算控制点的边界
                for (int i = 0; i < drawPathList.size(); i++) {
                    //构造一个区域对象，左闭右开的。
                    RectF r = new RectF();
                    Path path = drawPathList.get(i).path;
                    path.computeBounds(r, true);
                    //设置区域路径和剪辑描述的区域
                    re.setPath(path, new Region((int) r.left, (int) r.top, (int) r.right, (int) r.bottom));
                    Log.e("--点击是否则范围内----", "" + re.contains((int) event.getX(), (int) event.getY()) + " " + i);
                    if (re.contains((int) event.getX(), (int) event.getY())) {
                        curposition = i;
                        break;
                    } else {
                        curposition = Integer.MAX_VALUE;
                    }

                }
                for (int i = 0; i < drawPathList.size(); i++) {
                    //构造一个区域对象，左闭右开的。
                    RectF r = new RectF();
                    Path path = new Path();
                    path.addCircle(drawPathList.get(i).stopX, drawPathList.get(i).stopY, 10, Path.Direction.CCW);
                    path.computeBounds(r, true);
                    //设置区域路径和剪辑描述的区域
                    re.setPath(path, new Region((int) r.left, (int) r.top, (int) r.right, (int) r.bottom));
                    Log.e("--拖动圆点是否则范围内----", "" + re.contains((int) event.getX(), (int) event.getY()) + " " + i);
                    //在封闭的path内返回true 不在返回false
                    if (re.contains((int) event.getX(), (int) event.getY())) {
                        rcurposition = i;
                        isReMove = true;
                        break;
                    } else {
                        rcurposition = Integer.MAX_VALUE;
                        isReMove = false;
                    }

                }
                for (int i = 0; i < drawPathList.size(); i++) {
                    //构造一个区域对象，左闭右开的。
                    RectF r = new RectF();
                    Path path = new Path();
                    jiantouStart(drawPathList.get(i).startX, drawPathList.get(i).startY,
                            drawPathList.get(i).stopX, drawPathList.get(i).stopY);
                    path.moveTo(drawPathList.get(i).startX, drawPathList.get(i).startY);
                    path.lineTo(x24, y24);
                    path.lineTo(x23, y23);
                    path.moveTo(drawPathList.get(i).stopX, drawPathList.get(i).stopY);
                    path.lineTo(x3, y3);
                    path.lineTo(x4, y4);
                    path.close();
                    path.computeBounds(r, true);
                    //设置区域路径和剪辑描述的区域
                    re.setPath(path, new Region((int) r.left, (int) r.top, (int) r.right, (int) r.bottom));
                    //在封闭的path内返回true 不在返回false
                    Log.e("--拖动箭头是否则范围内----", "" + re.contains((int) event.getX(), (int) event.getY()) + " " + i);
                    if (re.contains((int) event.getX(), (int) event.getY())) {
                        rcurposition1 = i;
                        isReMove1 = true;
                        break;
                    } else {
                        rcurposition1 = Integer.MAX_VALUE;
                        isReMove1 = false;
                    }

                }
                isMove = false;
                mPath = new Path();
                startX = (int) event.getX();
                startY = (int) event.getY();
                mPath.moveTo(startX, startY);

                break;
            case MotionEvent.ACTION_MOVE:
                isMove = true;
                Log.e("move", "move");
                stopX = (int) event.getX();
                stopY = (int) event.getY();
                Log.e("isRemove", isReMove + "");
                if (isMove) {
                    if (isReMove || isReMove1) {
                        if (isReMove) {
                            Redraws(drawPathList.get(rcurposition).startX, drawPathList.get(curposition).startY, stopX, stopY);
                        }
                        if (isReMove1) {
                            x = stopX - startX;
                            y = stopY - startY;
                            Redraws(drawPathList.get(rcurposition1).startX + x, drawPathList.get(rcurposition1).startY + y,
                                    drawPathList.get(rcurposition1).stopX + x, drawPathList.get(rcurposition1).stopY + y);
                        }
                    } else {
                        draws();
                    }
                }

                break;
            case MotionEvent.ACTION_UP:
                Log.e("up", "up");
                if (isMove) {
                    if (isReMove || isReMove1) {
                        if (isReMove) {
                            canvas = mSurfaceHolder.lockCanvas();
                            Rect rectF = new Rect(0, 0, getWidth(), getHeight());
                            canvas.drawBitmap(bitmap, null, rectF, null);
                            drawPathList.set(rcurposition, new DrawPath(mpaint, drawPathList.get(rcurposition).startX, drawPathList.get(rcurposition).startY,
                                    stopX, stopY, true));
                            for (int i = 0; i < drawPathList.size(); i++) {
                                //把path中的路线绘制出来
                                canvas.drawPath(drawPathList.get(i).path, drawPathList.get(i).paint);
                            }
                        }
                        if (isReMove1) {
                            canvas = mSurfaceHolder.lockCanvas();
                            Rect rectF1 = new Rect(0, 0, getWidth(), getHeight());
                            canvas.drawBitmap(bitmap, null, rectF1, null);
                            drawPathList.set(rcurposition1, new DrawPath(mpaint, drawPathList.get(rcurposition1).startX + x, drawPathList.get(rcurposition1).startY + y,
                                    drawPathList.get(rcurposition1).stopX + x, drawPathList.get(rcurposition1).stopY + y, true));
                            for (int i = 0; i < drawPathList.size(); i++) {
                                //把path中的路线绘制出来
                                canvas.drawPath(drawPathList.get(i).path, drawPathList.get(i).paint);
                            }
                        }
                    } else {
                        stopX = (int) event.getX();
                        stopY = (int) event.getY();
                        canvas = mSurfaceHolder.lockCanvas();
                        Rect rectF = new Rect(0, 0, getWidth(), getHeight());
                        canvas.drawBitmap(bitmap, null, rectF, null);
                        for (int i = 0; i < drawPathList.size(); i++) {
                            drawPathList.set(i, new DrawPath(mpaint, drawPathList.get(i).startX, drawPathList.get(i).startY,
                                    drawPathList.get(i).stopX, drawPathList.get(i).stopY, false));
                        }
                        drawPathList.add(new DrawPath(mpaint, startX, startY, stopX, stopY, true));
                        for (int i = 0; i < drawPathList.size(); i++) {
                            //把path中的路线绘制出来
                            canvas.drawPath(drawPathList.get(i).path, drawPathList.get(i).paint);
                        }
                    }

                    mSurfaceHolder.unlockCanvasAndPost(canvas);
                } else {
                    canvas = mSurfaceHolder.lockCanvas();
                    Rect rectF = new Rect(0, 0, getWidth(), getHeight());
                    canvas.drawBitmap(bitmap, null, rectF, null);
                    for (int i = 0; i < drawPathList.size(); i++) {
                        if (i == curposition) {
                            drawPathList.set(i, new DrawPath(mpaint, drawPathList.get(i).startX, drawPathList.get(i).startY,
                                    drawPathList.get(i).stopX, drawPathList.get(i).stopY, true));
                            canvas.drawPath(drawPathList.get(i).path, drawPathList.get(i).paint);
                        } else {
                            drawPathList.set(i, new DrawPath(mpaint, drawPathList.get(i).startX, drawPathList.get(i).startY,
                                    drawPathList.get(i).stopX, drawPathList.get(i).stopY, false));
                            canvas.drawPath(drawPathList.get(i).path, drawPathList.get(i).paint);
                        }

                    }

                    mSurfaceHolder.unlockCanvasAndPost(canvas);
                }

                break;
        }
        return true;
    }


    public void draws() {
        if (bitmap == null) {
            Toast.makeText(getContext(), "加载图片失败", Toast.LENGTH_SHORT).show();
            Log.e("msg", "加载图片失败");
            return;
        }
        canvas = mSurfaceHolder.lockCanvas();
        Rect rectF = new Rect(0, 0, getWidth(), getHeight());   //w和h分别是屏幕的宽和高，也就是你想让图片显示的宽和高
        canvas.drawBitmap(bitmap, null, rectF, null);
        for (int i = 0; i < drawPathList.size(); i++) {
            //把path中的路线绘制出来
            canvas.drawPath(drawPathList.get(i).path, drawPathList.get(i).paint);
        }
        jiantouStart(startX, startY, stopX, stopY);
        jiantou(startX, startY, stopX, stopY);
        mSurfaceHolder.unlockCanvasAndPost(canvas);

    }

    public void Redraws(int rstartX, int rstartY, int rstopX, int rstopY) {
        if (bitmap == null) {
            Toast.makeText(getContext(), "加载图片失败", Toast.LENGTH_SHORT).show();
            Log.e("msg", "加载图片失败");
            return;
        }
        canvas = mSurfaceHolder.lockCanvas();
        Rect rectF = new Rect(0, 0, getWidth(), getHeight());   //w和h分别是屏幕的宽和高，也就是你想让图片显示的宽和高
        canvas.drawBitmap(bitmap, null, rectF, null);
        for (int i = 0; i < drawPathList.size(); i++) {
            //把path中的路线绘制出来
            if (curposition == i) {
                jiantouStart(rstartX, rstartY, rstopX, rstopY);
                jiantou(rstartX, rstartY, rstopX, rstopY);
            } else {
                canvas.drawPath(drawPathList.get(i).path, drawPathList.get(i).paint);
            }
        }
        mSurfaceHolder.unlockCanvasAndPost(canvas);

    }

    int x3 = 0;
    int y3 = 0;
    int x4 = 0;
    int y4 = 0;

    int x23 = 0;
    int y23 = 0;
    int x24 = 0;
    int y24 = 0;


    public void initPaint() {
        mpaint.setStyle(Paint.Style.STROKE);
        mpaint.setColor(Color.RED);
        mpaint.setAntiAlias(true);
        mpaint.setStyle(Paint.Style.FILL);
        mpaint.setStrokeWidth(1);
    }

    public void jiantouStart(int startX, int startY, int stopX, int stopY) {
        double d = Math.abs(stopX - startX) * Math.abs(stopX - startX) + Math.abs(stopY - startY) * Math.abs(stopY - startY);
        int r = (int) Math.sqrt(d);//两点之间的距离
        double H = 44; // 箭头的高度
        double L = 21; // 底边的一半

        x3 = 0;
        y3 = 0;
        x4 = 0;
        y4 = 0;

        x23 = 0;
        y23 = 0;
        x24 = 0;
        y24 = 0;

        double awrad = Math.atan(L / H); // 箭头角度
        double arraow_len = Math.sqrt(L * L + H * H); // 箭头的长度
        double[] arrXY_1 = rotateVec(stopX - startX, stopY - startY, awrad, true, arraow_len);
        double[] arrXY_2 = rotateVec(stopX - startX, stopY - startY, -awrad, true, arraow_len);
        //add
        double H2 = 30;
        double L2 = 10;
        double awrad2 = Math.atan(L2 / H2); // 箭头角度
        double arraow_len2 = Math.sqrt(L2 * L2 + H2 * H2); // 箭头的长度
        double[] arrXY2_1 = rotateVec(stopX - startX, stopY - startY, awrad2, true, arraow_len2);
        double[] arrXY2_2 = rotateVec(stopX - startX, stopY - startY, -awrad2, true, arraow_len2);


        double x_3 = stopX - arrXY_1[0]; // (x3,y3)第一个端点
        double y_3 = stopY - arrXY_1[1];
        double x_4 = stopX - arrXY_2[0]; // (x4,y4)第二个端点
        double y_4 = stopY - arrXY_2[1];

        double x2_3 = stopX - arrXY2_1[0]; // (x3,y3)箭头尾巴的第一个端点
        double y2_3 = stopY - arrXY2_1[1];
        double x2_4 = stopX - arrXY2_2[0]; // (x4,y4)箭头尾巴的第二个端点
        double y2_4 = stopY - arrXY2_2[1];


        Double X3 = new Double(x_3);
        x3 = X3.intValue();
        Double Y3 = new Double(y_3);
        y3 = Y3.intValue();
        Double X4 = new Double(x_4);
        x4 = X4.intValue();
        Double Y4 = new Double(y_4);
        y4 = Y4.intValue();

        //add
        Double X23 = new Double(x2_3);
        x23 = X23.intValue();
        Double Y23 = new Double(y2_3);
        y23 = Y23.intValue();
        Double X24 = new Double(x2_4);
        x24 = X24.intValue();
        Double Y24 = new Double(y2_4);
        y24 = Y24.intValue();
    }

    public void jiantou(int startX, int startY, int stopX, int stopY) {

        Path triangle = new Path();

        triangle.moveTo(startX, startY);
        triangle.lineTo(x24, y24);
        triangle.lineTo(x23, y23);
        triangle.moveTo(stopX, stopY);
        triangle.lineTo(x3, y3);
        triangle.lineTo(x4, y4);
        triangle.close();
        canvas.drawPath(triangle, mpaint);
    }


    /**
     * 计算三角形的其他两个点
     *
     * @param px
     * @param py
     * @param ang
     * @param isChLen
     * @param newLen
     * @return
     */
    public double[] rotateVec(int px, int py, double ang, boolean isChLen, double newLen) {
        double mathstr[] = new double[2];
        //矢量旋转函数，参数含义分别是x分量、y分量、旋转角、是否改变长度、新长度
        double vx = px * Math.cos(ang) - py * Math.sin(ang);
        double vy = px * Math.sin(ang) + py * Math.cos(ang);
        if (isChLen) {
            double d = Math.sqrt(vx * vx + vy * vy);
            vx = vx / d * newLen;
            vy = vy / d * newLen;
            mathstr[0] = vx;
            mathstr[1] = vy;
        }
        return mathstr;
    }

    @Override
    public boolean handleMessage(Message msg) {
        canvas = mSurfaceHolder.lockCanvas();
        //这里相当于是一个预览图
        Rect rectF = new Rect(0, 0, viewWidth, viewHeight);   //w和h分别是屏幕的宽和高，也就是你想让图片显示的宽和高
        if (bitmap != null && canvas != null)
            canvas.drawBitmap(bitmap, null, rectF, null);
        if (canvas != null)
            mSurfaceHolder.unlockCanvasAndPost(canvas);
        startDraw = false;
        return false;
    }


    public class DrawPath {

        public Paint paint;
        public Path path;
        public int startX;
        public int stopX;
        public int startY;
        public int stopY;
        public boolean active;

        public DrawPath(Paint paint, int startX, int startY, int stopX, int stopY, boolean active) {
            this.paint = paint;
            this.startX = startX;
            this.stopX = stopX;
            this.startY = startY;
            this.stopY = stopY;
            this.active = active;
            Path mPatha = new Path();
            jiantouStart(startX, startY, stopX, stopY);
            if (active) {
                mPatha.moveTo(startX, startY);
                mPatha.addCircle(startX, startY, 10, Path.Direction.CCW);
                mPatha.moveTo(startX, startY);
                mPatha.lineTo(x24, y24);
                mPatha.lineTo(x23, y23);
                mPatha.moveTo(stopX, stopY);
                mPatha.addCircle(stopX, stopY, 10, Path.Direction.CCW);
                mPatha.moveTo(stopX, stopY);
                mPatha.lineTo(x3, y3);
                mPatha.lineTo(x4, y4);
                mPatha.close();
            } else {
                mPatha.moveTo(startX, startY);
                mPatha.lineTo(x24, y24);
                mPatha.lineTo(x23, y23);
                mPatha.moveTo(stopX, stopY);
                mPatha.lineTo(x3, y3);
                mPatha.lineTo(x4, y4);
                mPatha.close();
            }
            path = mPatha;
        }

    }


}
